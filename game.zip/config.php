<?php
define("PAYURL","http://www.fjlmnet.com/api/v3.index/starpos");//支付地址
define("MCHID","10000");//支付店号
define("KEY","H6eazU1vXrTzg0KU6snaasJzgLRXPUsM");//支付密匙
define("NOTIFYURL","http://192.168.1.88/paydemo/game/notify.php");
